// {1-build} g++ ./main.cpp -o ./main.exe   //compiler file name -o output file name to execute   
// {2-run}  ./main.exe
//{3-clear}rm  filename //to remove 

#include <iostream>

int main ()
{
    std::cout << "hello" <<std::endl;
     return 0;
}