#include "Wifi.hpp"
#include <iostream>

void WIFI_Init()
{
    std::cout << "WIFI INIT is Working" <<std::endl;
}