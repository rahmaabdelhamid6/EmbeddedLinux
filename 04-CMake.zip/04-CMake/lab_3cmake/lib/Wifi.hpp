#ifndef _WIFI_H
#define _WIFI_H

void WIFI_Init();
#endif