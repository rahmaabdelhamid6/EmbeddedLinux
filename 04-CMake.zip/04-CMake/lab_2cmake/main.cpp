#include <iostream>
#include "calc.hpp"  //el mantki hna ni #include "include/calc.hpp" lkn na b include "calc.hpp" bs 
//w d 3chan elly bybuild el code na mn khlal el Cmake f na feh ha3rfo n feh folder esmu include y3tbro zyo zy lab_2cmake ka'nhum nfs el path 

int main ()
{
    std::cout << "hello" <<std::endl;
    std::cout << sum (1,2)<<std::endl;
    std::cout << X <<std::endl;
    return 0;
}