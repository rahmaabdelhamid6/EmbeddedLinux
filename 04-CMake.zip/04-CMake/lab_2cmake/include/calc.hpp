#define X  10
int sum (int x , int y);